APPname = 'Расписание НКПТиУ'
version = '1.0.0'
MAINTENANCE_MODE = False

max_queue = 10

all_groups = ['Исп-232', 'Исп-233']
all_teachers = ['Демиденко Наталья Ильинична', 'Киреева Ирина Андреева']
all_auditories = ['405-1']