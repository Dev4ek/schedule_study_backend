from .lesson import Lesson_input, Days, Schedule_output, Remove_lesson
from .time import Day_to_num, Num_to_day, Num_to_month, Put_time, Remove_time
from .replace import Replace_input, Replace_remove, Replace_output

